package ca.sheridancollege.project;

public class BlackjackGameStart {

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		BlackjackGame game = new BlackjackGame("Game 1");
		game.play();
	}

}